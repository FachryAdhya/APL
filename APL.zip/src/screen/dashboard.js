import React, {useState,useEffect} from 'react';
import { View, SafeAreaView, Text, ScrollView, StyleSheet, ActivityIndicator, RefreshControl} from 'react-native';
import axios from 'axios';

const DashboardScreen = () => {

    const urlGetDataIndonesia = 'https://api.kawalcorona.com/indonesia/';
    const [dataIndonesia, setDataIndonesia] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isRefresh, setIsRefresh] = useState(false)

    const fetchDataIndonesia = async () => {
        setLoading(true)
        const response= await axios.get(urlGetDataIndonesia)
        const {data,status} = response
        if (status === 200 && data){
            setDataIndonesia(data[0]);
            setLoading(false)
            setIsRefresh(false)
        }
    };

    // const dispatch = React.useDispatch();

    // useEffect(() => {
    //     dispatch(fetchDataIndonesia())
    // }, [dispatch]);

    useEffect(() => {
        fetchDataIndonesia();
    }, []);

    const onRefresh = () => {
        setIsRefresh(true)
        fetchDataIndonesia();
    }

    if (loading){
        return (
            <SafeAreaView style={styles.fill}>
                <View style={[styles.fill, styles.center]}>
                    <ActivityIndicator size={'large'} />
                </View>
            </SafeAreaView>
        )
    }

    return (
        <SafeAreaView style={[styles.container,styles.bgDark]}>
            <ScrollView 
                refreshControl={
                    <RefreshControl
                        onRefresh={onRefresh}
                        refreshing={isRefresh}    
                    />
                }
                style={[styles.sView]}
            >
                <Text style={[styles.title, styles.textLight]}>Data COVID-19 {dataIndonesia.name}</Text>
                <View style={[styles.center]}>
                    <View style={[styles.box,styles.bgYellow]}>
                        <Text style={[styles.boxTitle,styles.textDark]}>Positif</Text>
                        <Text style={[styles.boxValue,styles.textDark]}>{dataIndonesia.positif}</Text>
                    </View>
                    <View style={[styles.box,styles.bgGreen]}>
                        <Text style={[styles.boxTitle,styles.textDark]}>Sembuh</Text>
                        <Text style={[styles.boxValue,styles.textDark]}>{dataIndonesia.sembuh}</Text>
                    </View>
                    <View style={[styles.box,styles.bgBlue]}>
                        <Text style={[styles.boxTitle,styles.textDark]}>Sedang Dirawat</Text>
                        <Text style={[styles.boxValue,styles.textDark]}>{dataIndonesia.dirawat}</Text>
                    </View>
                    <View style={[styles.box,styles.bgRed]}>
                        <Text style={[styles.boxTitle,styles.textLight]}>Meninggal</Text>
                        <Text style={[styles.boxValue,styles.textLight]}>{dataIndonesia.meninggal}</Text>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    fill:{
        flex:1,
    },
    center:{
        justifyContent: 'center',
        alignItems: 'center',
    },
    container: {
        flex: 1,
        padding: 10,
        alignItems: 'center',
    },
    sView:{
        flex: 1,
        alignSelf: 'stretch',
    },
    title:{
        fontSize: 36,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 20,
    },
    itemContainer: {
        marginBottom: 12,
    },
    box:{
        height: 100,
        width: 200,
        borderRadius: 5,
        margin: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    bgDark:{
        backgroundColor: '#334756',
    },
    bgLight:{
        backgroundColor: '#F6F6F6',
    },
    bgYellow:{
        backgroundColor: '#F5B971',
    },
    bgRed:{
        backgroundColor: '#FF7171',
    },
    bgGreen:{
        backgroundColor: '#77D970'
    },
    bgBlue:{
        backgroundColor: '#A1CAE2'
    },
    textLight:{
        color:'#F6F6F6'
    },
    textDark:{
        color:'#212121'
    },
    boxTitle:{
        fontSize: 16,
        fontWeight: 'bold'
    },
    boxValue:{
        fontSize: 28,
        padding: 12,
        fontWeight: 'bold',
    }
})

export default DashboardScreen;