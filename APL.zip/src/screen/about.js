import React, {useState,useEffect} from 'react';
import { View, SafeAreaView, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';

const AboutScreen = () => {
    return (
        <SafeAreaView style={[styles.container,styles.bgDark]}>
            <View style={[styles.fullWidth]}>
                <Text style={[styles.title, styles.textLight]}>APL React Native</Text>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    fill:{
        flex:1,
    },
    center:{
        justifyContent: 'center',
        alignItems: 'center',
    },
    fullWidth:{
        alignSelf: 'stretch',
    },
    container: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 15,
        alignItems: 'center',
    },
    title:{
        fontSize: 36,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 20,
    },
    itemContainer: {
        color: '#F6F6F6',
        marginBottom: 5,
        backgroundColor: '#6D8299',
        height: 80,
        borderRadius: 15,
        paddingLeft: 10,
        paddingTop: 10,
    },
    box:{
        height: 100,
        width: 200,
        borderRadius: 5,
        margin: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    bgDark:{
        backgroundColor: '#334756',
    },
    bgLight:{
        backgroundColor: '#F6F6F6',
    },
    bgYellow:{
        backgroundColor: '#F5B971',
    },
    bgRed:{
        backgroundColor: '#FF7171',
    },
    bgGreen:{
        backgroundColor: '#77D970'
    },
    bgBlue:{
        backgroundColor: '#A1CAE2'
    },
    textLight:{
        color:'#F6F6F6'
    },
    textDark:{
        color:'#212121'
    },
    boxTitle:{
        fontSize: 16,
        fontWeight: 'bold'
    },
    boxValue:{
        fontSize: 28,
        padding: 12,
        fontWeight: 'bold',
    },
    listTitle:{
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    listValue:{
        fontSize: 18,
        fontWeight: 'bold',
    }
})

export default AboutScreen;