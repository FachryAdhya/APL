import React, {useState,useEffect} from 'react';
import { View, SafeAreaView, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, Modal,Pressable } from 'react-native';
import axios from 'axios';

const ListScreen = () => {
    const urlGetDataProvinsi = 'https://api.kawalcorona.com/indonesia/provinsi/';
    const [dataProvinsi, setDataProvinsi] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isRefresh, setIsRefresh] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [dataModal, setDataModal] = useState([])
    
    const fetchDataProvinsi = async () => {
        setLoading(true)
        const response= await axios.get(urlGetDataProvinsi)
        const {data,status} = response
        if (status === 200 && data){
            setDataProvinsi(data);
            setLoading(false)
            setIsRefresh(false)
        }
    };

    useEffect(() => {
        fetchDataProvinsi();
    }, []);

    const onRefresh = () => {
        setIsRefresh(true)
        fetchDataProvinsi();
    }

    const openModal = (id) =>{
        setLoading(true)
        for(let i = 0; i<dataProvinsi.length;i++){
            if(dataProvinsi[i].attributes.Kode_Provi === id){
                setDataModal(dataProvinsi[i])
                setLoading(false)
                setModalVisible(!modalVisible)
                return;
            }
        }
    }

    if (loading){
        return (
            <SafeAreaView style={styles.fill}>
                <View style={[styles.fill, styles.center]}>
                    <ActivityIndicator size={'large'} />
                </View>
            </SafeAreaView>
        )
    }
    return (
        <SafeAreaView style={[styles.container,styles.bgDark]}>
            <View style={[styles.fullWidth]}>
                <FlatList
                    data={dataProvinsi}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity 
                                style={[styles.itemContainer]} 
                                onPress={() => {
                                    openModal(item.attributes.Kode_Provi);
                                }}     
                            >
                                <Text style={[styles.listTitle,styles.textLight]}>{item.attributes.Provinsi}</Text>
                                <Text style={[styles.listValue,styles.textLight]}>{`Positif: ${item.attributes.Kasus_Posi}`}</Text>
                            </TouchableOpacity>
                        )
                    }}
                    keyExtractor={(item) => item.attributes.FID}
                    onRefresh={onRefresh}
                    refreshing={isRefresh}
                    ListHeaderComponent={()=><Text style={[styles.title, styles.textLight]}>Data COVID-19 per Provinsi</Text>}    
                >
                </FlatList>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={modalVisible}
                    onRequestClose={() => {
                    Alert.alert("Modal has been closed.");
                    setModalVisible(!modalVisible);
                    }}
                >
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <Text style={styles.modalTitle}>{modalVisible? dataModal.attributes.Provinsi : '-'}</Text>
                            <Text style={styles.modalText}>{modalVisible? 'Kasus Positif: ' + dataModal.attributes.Kasus_Posi : '-'}</Text>
                            <Text style={styles.modalText}>{modalVisible? 'Kasus Sembuh: ' + dataModal.attributes.Kasus_Semb : '-'}</Text>
                            <Text style={styles.modalText}>{modalVisible? 'Kasus Meninggal: ' + dataModal.attributes.Kasus_Meni : '-'}</Text>
                            <Pressable
                            style={[styles.button, styles.buttonClose]}
                            onPress={() => setModalVisible(!modalVisible)}
                            >
                                <Text style={styles.textStyle}>Close</Text>
                            </Pressable>
                        </View>
                    </View>
                </Modal>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    fill:{
        flex:1,
    },
    center:{
        justifyContent: 'center',
        alignItems: 'center',
    },
    fullWidth:{
        alignSelf: 'stretch',
    },
    container: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 15,
        alignItems: 'center',
    },
    title:{
        fontSize: 36,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 20,
    },
    itemContainer: {
        color: '#F6F6F6',
        marginBottom: 5,
        backgroundColor: '#6D8299',
        height: 85,
        borderRadius: 15,
        paddingLeft: 10,
        paddingTop: 10,
    },
    box:{
        height: 100,
        width: 200,
        borderRadius: 5,
        margin: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    bgDark:{
        backgroundColor: '#334756',
    },
    bgLight:{
        backgroundColor: '#F6F6F6',
    },
    bgYellow:{
        backgroundColor: '#F5B971',
    },
    bgRed:{
        backgroundColor: '#FF7171',
    },
    bgGreen:{
        backgroundColor: '#77D970'
    },
    bgBlue:{
        backgroundColor: '#A1CAE2'
    },
    textLight:{
        color:'#F6F6F6'
    },
    textDark:{
        color:'#212121'
    },
    boxTitle:{
        fontSize: 16,
        fontWeight: 'bold',
    },
    boxValue:{
        fontSize: 28,
        padding: 12,
        fontWeight: 'bold',
    },
    listTitle:{
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    listValue:{
        fontSize: 18,
        fontWeight: 'bold',
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22
    },
    modalView: {
        margin: 20,
        backgroundColor: "white",
        borderRadius: 10,
        padding: 35,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
        width: 0,
        height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5
    },
    button: {
        marginTop: 10,
        borderRadius: 5,
        padding: 10,
        elevation: 2
    },
    buttonOpen: {
        backgroundColor: "#F194FF",
    },
    buttonClose: {
        backgroundColor: "#AAA492",
    },
    textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
    },
    modalTitle: {
        marginBottom: 25,
        textAlign: "center",
        fontWeight: 'bold',
        fontSize: 16
    },
    modalText: {
        marginBottom: 15,
    }
})

export default ListScreen;