import React from "react"
import RouteNavigation from "./navigation"

const App = () => {
    return(
        <RouteNavigation />
    )
}

export default App;